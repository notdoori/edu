<template>
<v-layout
  row wrap pt-5 text-xs-center
  style="max-width:500px; margin:0 auto;"
>
    <v-flex xs12>
      <h1>Users</h1>
      <p>유저를 검색해 주세요.</p>
    </v-flex>

    <v-flex xs12>
        <v-text-field v-model="userId" label="유저 번호를 입력하세요.">
        </v-text-field>
        <!-- 폼에서 입력 받은 userId 를 파라미터로 전달 -->
        <!-- <v-btn @click="$router.push({path: `users/${userId}`})"> -->
        <v-btn @click="$router.push({name: 'users-detail', params: {id: userId}})">
            검색
        </v-btn>
    </v-flex>
    
    <v-flex xs12>
        <router-view></router-view>
    </v-flex>
    
      <!-- <p>유저 번호는 {{ userId }} 입니다.</p>
      {{ $route.params.name}} <br>
      <h1>그룹: {{ $route.query.group}}</h1>
      <h1>카테고리: {{ $route.query.category}}</h1>
      <h1>이름: {{ $route.query.name}}</h1>
      <h1>주소: {{ $route.query.address}}</h1> -->
</v-layout>
</template>

<script>
export default {
    //computed: {
    //    userId() {
    //        return this.$route.params.userId;
    //    }
    //},
    data () {
         return {
             userId: null
         }
    },
    beforeRouteEnter (to, from, next) {
        console.log('boforeRouteEnter');
        next();
    },
    beforeRouteLeave(to, from, next) {
        console.log('boforeRouteLeave');
        next();
    },
    created() {
        //console.log("router", this.$router); // router : router.js 파일에서 export 한 Router 객체 
        //console.log("route", this.$route); // 현재 주소에 의해 선택된 route 정보.
        console.log('created');
    },
    destroyed() {
        console.log('destroyed');
    }
}
</script>

<style>

</style>