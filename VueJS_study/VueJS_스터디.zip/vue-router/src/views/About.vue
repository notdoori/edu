<template>
  <div class="text-xs-center">
    This is About Page
    <h1>클릭</h1>
    <!-- 클릭 이벤트 없이 컴포넌트 이동 하는 방법 -->
    <router-link :to="{name: 'home'}">
      <h1>클릭</h1>
    </router-link>
    
  </div>
</template>
