<template>
  <v-app id="inspire">
    <v-navigation-drawer
      v-model="drawer"
      fixed
      app
    >
      <v-list dense>
        <!-- $route.push({'XXX': 'YYY'}) => route.js 의 route 속성에 접근
             XXX : route 속성 중 XXX 프로퍼티. 
             YYY : XXX 프로퍼티의 값.
        -->
        <!-- <v-list-tile @click="$router.push({name: 'home'})"> -->
        <!-- <v-list-tile @click="$router.push({path: '/'})"> -->
        <!-- path 값 만으로도 이동 가능 함. -->
        <!-- <v-list-tile @click="$router.push('/')">  -->
        <!-- 클릭 이벤트 사용하지 않고 router 속성을 이용하는 방법.
             router 속성을 사용하는 경우 내용이 활성화 되어 보임.
             활성화 조건은 브라우저 주소창의 내용이 
             routes 설정 중 path 값의 포함 여부 임.
             exact 옵션은 포함이 아닌 whole word 로 매치 시켜 활성화 여부 결정함.
        -->
        <v-list-tile router :to="{name: 'home'}" exact>
          <v-list-tile-action>
            <i class="fas fa-home"></i>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Home</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <!-- <v-list-tile @click="$router.push({name: 'about'})"> -->
        <!-- <v-list-tile @click="$router.push({path: '/about'})"> -->
        <!-- <v-list-tile @click="$router.push('/about')">  -->
        <v-list-tile router :to="{name: 'about'}" exact>
          <v-list-tile-action>
            <i class="fas fa-user"></i>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>About</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
        <!-- <v-list-tile router :to="{
                                   name: 'users',
                                   params:{
                                     userId: 4321,
                                     name: 'hoza'
                                   },
                                   query: {
                                     group: 'member',
                                     category: 'trial'
                                   }
                                  }" exact> -->
        <v-list-tile router :to="{name: 'users'}">
          <v-list-tile-action>
            <i class="fas fa-user"></i>
          </v-list-tile-action>
          <v-list-tile-content>
            <v-list-tile-title>Users</v-list-tile-title>
          </v-list-tile-content>
        </v-list-tile>
      </v-list>
    </v-navigation-drawer>
    <v-toolbar color="indigo" dark fixed app>
      <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
      <v-toolbar-title>Application</v-toolbar-title>
    </v-toolbar>
    <v-content>
      <!-- 라우터의 컴포넌트가 표시될 위치 표시 -->
      <router-view></router-view>
    </v-content>
    <v-footer color="indigo" app>
      <span class="white--text">&copy; 2017</span>
    </v-footer>
  </v-app>
</template>

<script>
export default {
  data: () => ({
    drawer: null
  }),
  props: {
    source: String
  },
  methods: {
    goHome () {
      alert("goHome 클릭");
    },
    goAbout () {
      alert("goAbout 클릭");
    }
  }
}
</script>