import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'

Vue.use(Router)

// const About = () => {
//   return import(/* webpackChunkName: "about" */ './views/About.vue')
// }

const About = () => import(/* webpackChunkName: "about" */ './views/About.vue')
const Users = () => import(/* webpackChunkName: "users" */ './views/Users.vue')
const UsersDetail = () => import(/* webpackChunkName: "users-detail" */ './views/UsersDetail.vue')
const UsersEdit = () => import(/* webpackChunkName: "users-edit" */ './views/UsersEdit.vue')

// const Users = () => {
//   return import(/* webpackChunkName: "users" */ './views/Users.vue')
// }

export default new Router({
  mode: 'history', // Vue router 의 기본 모드는 hash, hash 모드에서는 '#/' 로 시작해야 주소로 인식함.
  base: process.env.BASE_URL,
  routes: [
    {
      path: '/',
      name: 'home',
      // route.js 가 로드 될 때 컴포넌트를 로드 함.
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      // 요청이 발생 할 때 컴포넌트를 로드 하게 하는 방법.
      //component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
      component: About
    },
    {
      //path: '/users/:userId',
      path: '/users',
      name: 'users',
      // router guard : 정해진 속성이 있음.
      //beforeEnter: (to, from, next) => { // from -> to 로 라우트 이동, next() 를 호출 해야 완전히 이동됨.
        //console.log('to: ', to, 'from: ', from); //to, from 은 route 객체 정보
      //  console.log('beforeEnter');
      //  next(); // 인자로 route 를 지정하는 경우 지정한 route 로 이동함.
      //},
      component: Users,
      children: [ //children(하위 라우터) : users 라는 주소 내부에서만 동작하는 라우터
        {
          path: ":id",
          name: "users-detail",
          component: UsersDetail
        },
        {
          path: ":id/edit",
          name: "users-edit",
          component: UsersEdit
        }
      ]
    }
  ]
})
