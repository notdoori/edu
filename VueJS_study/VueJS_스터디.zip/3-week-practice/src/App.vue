<template>
  <v-app>
    <v-content>
      <User/>
    </v-content>
  </v-app>

</template>

<script>
import User from "./components/User"

export default {
  name: "App",
  components: {
    User
  },
  methods: {
    removeTab(index){
    this.tabs.splice(index, 1)
    },
    addTab(){
      this.tabs.push('New Tab')
    }
  },
  data() {
    return {
      length: 15,
      tab: null,
      tabs: []
    }
  },
  watch: {
      length (val) {
        console.log('val: ', val);
        this.tab = val - 1;
        console.log('tab: ', this.tab);
      },
  }
}
</script>

<style scoped>
  .tab-close{
    float:right;
  }
  .tab-close:hover{
    transform: rotate(7deg);
  }
</style>