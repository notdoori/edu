<template>
  <div class="blue lighten-3 pa-3">
    <h1>User 컴포넌트</h1>
    <p>이름: 뷰제이에스</p>
    <p>{{ getDateAndTime(createdAt) }}</p>
    <p>{{ helloToMixin }}</p>
    <v-btn v-on:click="changeName">이름 변경</v-btn>
    <hr>
    <v-layout row wrap>
      <v-flex xs12 sm6>
        <!-- props => v-bind:하위 컴포넌트에서 props 사용을 위해 선언하는 변수명 = "현재 컴포넌트에서 전달할 값 "-->
        <!-- props 로 전달하는 데이터는 타입 제한 없음
             props 는 현재 컴포넌트의 데이터를 하위 컴포넌트에 연결 하여 현재 컴포넌트에서의 
             수정 사항이 하위 컴포넌트에 반영 되게 하는 것.
         -->
        <!-- <UserDetail v-bind:nameOfChild="name"></UserDetail> -->
        <!-- <UserDetail></UserDetail> -->

        <!-- $emit -->
        <UserDetail 
          v-bind:name="name" 
          v-bind:address="address" 
          v-bind:phone="phone" 
          v-bind:hasDog="hasDog"
        >
        </UserDetail>
      </v-flex>
      <v-flex xs12 sm6>
        <UserEdit
          v-bind:name="name" 
          v-bind:address="address" 
          v-bind:phone="phone" 
          v-bind:hasDog="hasDog"
          @child="parents"
        >
        </UserEdit>
      </v-flex>
    </v-layout>
  </div>
</template>

<script>
import UserDetail from "./UserDetail.vue"
import UserEdit from "./UserEdit.vue"
import {dateFormat} from "../mixins/dateFormat"

export default {
  components: {
    UserDetail,
    UserEdit
  },
  data() {
    return {
      name: 'Hoza',
      address: 'Seoul',
      phone: '1234-5678',
      hasDog: true,
      createdAt: null,
    }
  },
  created() {
    console.log('유저 컴포넌트');  
    this.createdAt = new Date();
  },
  computed: {
    helloToMixin() {
      return this.mixinData + ' 안녕하시오!'
    }
  },
  methods: {
    changeName() {
    //changeName: function () {
      this.name = "Hoza";
    },
    parents(user) {
      console.log("부모가 받았어.!");
      this.name = user.name;
      this.address = user.address;
      this.phone = user.phone;
      this.hasDog = user.hasDog;
    },
    // getDateAndTime(date) {
    //   if (date !== null) {
    //     let hour = date.getHours();
    //     let minutes = date.getMinutes();
    //     let fullDate = `${date.getFullYear()}/${date.getMonth()+ 1}/${date.getDate()}`

    //     return `${fullDate} ${hour}:${minutes}`;
    //   } else {
    //     return null;
    //   }
    // }
  },
  // mixins 속성에 할당된 정보는 현재 Vue 인스턴스내에 존재 하는 것 처럼 사용 할 수 있음.
  // 함수 이름이 동일한 경우 mixins 에 있는 함수 보다 현재 Vue 인스턴스내에 존재 하는 함수가 우선 순위가 있음.
  mixins: [dateFormat]
}
</script>