<template>
  <div class="red lighten-3 pa-3">
    <h3>자세한 회원 정보를 확인합니다.</h3>
    <p>상세 사항</p>
    <!-- <v-btn v-on:click="switchName">이름 변경</v-btn> -->
    <v-list dense>
      <v-list-tile>
        <v-list-tile-content>이름:</v-list-tile-content>
        <v-list-tile-content class="align-end">
          {{ name }}
        </v-list-tile-content>
      </v-list-tile>
      <v-list-tile>
        <v-list-tile-content>주소:</v-list-tile-content>
        <v-list-tile-content class="align-end">
          {{ address }}
        </v-list-tile-content>
      </v-list-tile>
      <v-list-tile>
        <v-list-tile-content>전화번호:</v-list-tile-content>
        <v-list-tile-content class="align-end">
          {{ phone }}
        </v-list-tile-content>
      </v-list-tile>
      <v-list-tile>
        <v-list-tile-content>반려견 유무:</v-list-tile-content>
        <v-list-tile-content class="align-end">
          {{ hasDogKr }}
        </v-list-tile-content>
      </v-list-tile>
      <v-list-tile>
        <v-list-tile-content>수정일자:</v-list-tile-content>
        <v-list-tile-content class="align-end">
          {{ getDateAndTime(editedDate) }}
        </v-list-tile-content>
      </v-list-tile>
    </v-list>
  </div>
</template>

<script>

import {eventBus} from "../main"
import {dateFormat} from "../mixins/dateFormat"

export default {
  //props: ['nameOfChild'],
  // 데이터 타입 등 옵션 기술을 위해서는 array 타입을 object 타입으로 변경 해야 함.
  // props : {
  //   nameOfChild: {
  //     type: String,
  //     default: 'LEGO'
  //   }
  // },
  props: ['name', 'address', 'phone', 'hasDog'],
  computed: {
    // sayHello() {
    //   return this.nameOfChild + ' 안녕하세요.';
    // }
    hasDogKr() {
      return this.hasDog === true ? '있음' : '없음';
    }
  },
  methods: {
    // switchName() {
      // props 로 전달 받은 데이터를 변경 하는 것은 가능 하지만,
      // 상위 컴포넌트에서 데이터 수정 사항 발생 시 상위 컴포넌트의 데이터로 변경됨.
      // 동작은 되지만, console 에는 warning 발생함.
    //   this.nameOfChild = '컴퓨터';
    // }
    // getDateAndTime(date) {
    //   if (date !== null) {
    //     let hour = date.getHours();
    //     let minutes = date.getMinutes();
    //     let fullDate = `${date.getFullYear()}/${date.getMonth()+ 1}/${date.getDate()}`

    //     return `${fullDate} ${hour}:${minutes}`;
    //   } else {
    //     return null;
    //   }
    // }
  },
  data() {
    return {
      editedDate: null
    }
  },
  created() {
    console.log('유저 디테일 컴포넌트');  
    eventBus.$on("userWasEdited", date => {
      this.editedDate = date;
    })
  },
  mixins: [dateFormat]
}
</script>
