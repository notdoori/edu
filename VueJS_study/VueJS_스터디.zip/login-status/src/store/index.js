import Vue from "vue";
import Vuex from "vuex";

import router from '../router'

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    userinfo: null,
    allUsers: [
      {id: 1, name: 'hoza', email: 'hoza@gmail.com', password: '123456'},
      {id: 1, name: 'lego', email: 'lego@gmail.com', password: '123456'}
    ],
    isLogin: false,
    isLoginError: false
  },
  mutations: {
    // 로그인 성공
    loginSuccess(state, payload) {
      state.isLogin = true;
      state.isLoginError = false;
      state.userInfo = payload;
    },
    // 로그인 실패
    loginError(state) {
      state.isLogin = false;
      state.isLoginError = true;
    },
    logOut(state) {
      state.isLogin = false;
      state.isLoginError = false;
      state.userinfo = null;
    }
  },
  actions: {
    // 로그인 시도
    login({state, commit}, payload) {
      //console.log(state, commit, payload);
      let selectedUser = null;
      state.allUsers.forEach(user => {
          if (user.email === payload.email) selectedUser = user;
      })

      // selectedUser === null ? commit('loginError')
      // : selectedUser.password !== payload.password ? commit('loginError') 
      // : commit('loginSuccess')
      if (selectedUser === null || selectedUser.password !== payload.password) {
        commit("loginError")
      } else {
        commit("loginSuccess", selectedUser);
        router.push({name: 'mypage'});
      }
    },
    login2(state, context, payload) {
      console.log(state, context, payload);
    },
    logOut({commit}) {
      commit("logOut");
      router.push({name: 'home'});
    }
  },
  modules: {}
});
