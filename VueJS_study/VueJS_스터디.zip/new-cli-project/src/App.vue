<template>
  <div>
    <AppStatus></AppStatus>
    <h1>{{ title }}</h1>
    <p>{{ count }}</p>
    <button v-on:click="count++">추가</button>
    <Home></Home>
    
  </div>
</template>

<script>
  import Home from './Home'

  export default { // Vue 객체를 export
    components: {
      Home
    },
    data() {
      return {
        title: '안녕하세요.',
        count: 1
      }
    }
  }
</script>
