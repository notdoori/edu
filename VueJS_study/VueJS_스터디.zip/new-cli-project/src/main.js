import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import vuetify from './plugins/vuetify';
import '@babel/polyfill'

// main.js 파일은 Vue 어플리케이션을 관장하는 역할을 수행함.
// component 를 어플리케이션 전체에서 사용하고자 하는 경우 main.js 파일에 추가함.

import Status from './Status' // 어플리케이션 전체에서 사용하고자 함.
Vue.component('AppStatus', Status); // 어플리케이션 전체에서 사용하고자 함.

Vue.config.productionTip = false

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')
