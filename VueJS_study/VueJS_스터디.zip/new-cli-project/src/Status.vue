<template>
  <h2>{{title}}</h2>
</template>

<script>
export default {
    data() {
        return {
            title: '상태 좋습니다.'
        }
    }
}
</script>

<style>

</style>