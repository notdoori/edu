<template>
  <v-container fill-height style="max-width:450px;">
      <v-layout align-center row wrap>
        <v-flex xs12>
            <v-alert
              :value="isLoginError"
              type="error"
            >
            아이디와 비밀 번호를 확인해 주세요.
            </v-alert>
            <v-alert
              :value="isLogin"
              type="success"
            >
            로그인이 완료되었습니다.
            </v-alert>
            <v-card>
                <v-toolbar dark flat>
                    <v-toolbar-title>로그인</v-toolbar-title>
                    <!-- <v-spacer></v-spacer> -->
                </v-toolbar>
                <div class="pa-3">
                    <v-text-field 
                    v-model="email"
                    label="이메일을 입력하세요."
                    >
                    </v-text-field>
                    <v-text-field 
                    v-model="password"
                    type="password"
                    label="패스워드를 입력하세요."
                    >
                </v-text-field>
                <v-btn v-if="isLogin" block depressed color="primary" @click="logIn(
                    {email:email, password:password})">
                    로그인
                </v-btn>
                <!-- <v-btn @click="test">
                    테스트
                </v-btn>
                <v-btn @click="postTest">
                    POST 테스트
                </v-btn> -->
                </div>
                
            </v-card>
            
        </v-flex>
      </v-layout>
  </v-container>
</template>

<script>

import {mapState, mapActions} from 'vuex'

//const axios = require('axios')
//import axios from 'axios'

export default {
    data() {
        return {
            email: null,
            password: null,            
        }
    },
    computed: {
        ...mapState(['isLogin', 'isLoginError'])
    },
    methods: {
        ...mapActions(['login', 'logIn']),
        /*test() {
            axios.get('https://reqres.in/api')
            // function(response) 형태로 사용하면 this 가 함수 내부가 되어 Vue 인스턴스에 접근 불가.
            // => 함수 형태로 변경 해야 Vue 인스터스의 data 등에 접근 가능함.
            //.then(function (response) { 
            .then(response => {
                // handle success
                console.log(response);
            })
            //.catch(function (error) {
            .catch(error => {
                // handle error
                console.log(error);
            })
            //.then(function () {
            .then(() => {
                // always executed
                console.log('test');
            });
        },*/
        // postTest() {
        //     axios.post('https://reqres.in/api/register', {
        //         email: "eve.holt@reqres.in",
        //         password: "pistol"
        //     })
        //     .then(response => {
        //         console.log(response);
        //     })
        //     .catch(error => {
        //         console.log(error);
        //     });
        // }
    }
}
</script>

<style>

</style>