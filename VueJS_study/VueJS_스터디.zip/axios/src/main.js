import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import vuetify from "./plugins/vuetify";

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  vuetify,
  // local storage 를 이용하여 로그인 상태 유지 시키는 기능은 보통 아래 처럼 사용함.
  beforeCreate() {
    this.$store.dispatch("getMemberInfo")
    console.log('ABC');
  },
  render: h => h(App)
}).$mount("#app");
