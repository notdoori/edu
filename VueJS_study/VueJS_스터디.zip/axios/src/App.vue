<template>
<!-- <div id="app"> -->
  <!-- <v-app id="inspire"> -->
    <v-app id="inspire">
      <v-navigation-drawer
        v-model="drawer"
        fixed
        app
      >
        <v-list dense>
          <v-list-item router :to="{name: 'home'}" exact>
            <v-list-item-action>
              <v-icon>mdi-home</v-icon>
            </v-list-item-action>
            <v-list-item-content>
              <v-list-item-title>Home</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <v-list-item v-if="isLogin === false" router :to="{name: 'login'}" exact>
            <v-list-item-action>
              <v-icon>mdi-email</v-icon>
            </v-list-item-action>
            <v-list-item-content>
              <v-list-item-title>로그인</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <v-list-item v-if="isLogin === true" router :to="{name: 'mypage'}" exact>
            <v-list-item-action>
              <v-icon>mdi-email</v-icon>
            </v-list-item-action>
            <v-list-item-content>
              <v-list-item-title>마이 페이지</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-navigation-drawer>
  
      <v-app-bar
        color="indigo"
        dark
        fixed
        app
      >
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
      <v-toolbar-title>Application</v-toolbar-title>
        <v-spacer></v-spacer>
        <v-menu offset-y v-if="isLogin">
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              v-bind="attrs"
              v-on="on"
              text
              icon
            >
              <v-icon>mdi-dots-vertical</v-icon>
            </v-btn>
          </template>
          <v-list>
            <v-list-item router :to="{name: 'mypage'}">
              <v-list-item-title>마이페이지</v-list-item-title>
            </v-list-item>
            <v-list-item @click="$store.dispatch('logOut')">
              <v-list-item-title>로그아웃</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
        <v-btn v-else router :to="{name: 'login'}">
          Log In
        </v-btn>
      </v-app-bar>
  
      <v-main>
        <keep-alive>
        <router-view></router-view>
        </keep-alive>
      </v-main>
    </v-app>
  <!-- </v-app> -->
<!-- </div> -->
</template>

<script>

  import {mapState} from 'vuex';

  export default {
    data: () => ({
      drawer: null
    }),
    computed: {
      ...mapState(['isLogin'])
    },
    props: {
      source: String
    }
  }
</script>