import Vue from "vue";
import Vuex from "vuex";

import router from '../router'

//const axios = require('axios')
import axios from 'axios'


Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    userinfo: null,
    allUsers: [
      {id: 1, name: 'hoza', email: 'hoza@gmail.com', password: '123456'},
      {id: 1, name: 'lego', email: 'lego@gmail.com', password: '123456'}
    ],
    isLogin: false,
    isLoginError: false
  },
  mutations: {
    // 로그인 성공
    loginSuccess(state, payload) {
      state.isLogin = true;
      state.isLoginError = false;
      state.userInfo = payload;
    },
    // 로그인 실패
    loginError(state) {
      state.isLogin = false;
      state.isLoginError = true;
    },
    logOut(state) {
      state.isLogin = false;
      state.isLoginError = false;
      state.userinfo = null;
    }
  },
  actions: {
    // 로그인 시도
    login({state, commit}, payload) {
      //console.log(state, commit, payload);
      let selectedUser = null;
      state.allUsers.forEach(user => {
          if (user.email === payload.email) selectedUser = user;
      })

      // selectedUser === null ? commit('loginError')
      // : selectedUser.password !== payload.password ? commit('loginError') 
      // : commit('loginSuccess')
      if (selectedUser === null || selectedUser.password !== payload.password) {
        commit("loginError")
      } else {
        commit("loginSuccess", selectedUser);
        router.push({name: 'mypage'});
      }
    },
    logOut({commit}) {
      commit("logOut");
      router.push({name: 'home'});
    },
    logIn({commit}, payload) {
      axios.post('https://reqres.in/api/login', payload) // payload 는 body 데이터
            .then(response => {
              console.log(response);

              let token = response.data.token;
              // browser 의 local storage 에 token 저장
              localStorage.setItem("access_token", token);

              dispatch("getMemberInfo");
                    
            })
            .catch(error => {
              //console.log(error);
              alert('이메일과 비밀번호를 확인 하세요.')
            });
    },
    getMemberInfo({commit}) {
      // browser 의 local storage 에서 token 획득
      let token = localStorage.getItem("access_token");
      if (token === null) return;
  
      // config : 보안 관련 설정, 헤더 및 헤더 값 추가 등에 사용.
      // 응답으로 수신한 token 을 HTTP 헤더에 추가
      let config = {
        headers: {
          "access-token": token
        }
      }
      axios.get('https://reqres.in/api/users/2', config) // 
      .then(res => {
        console.log(res);
        let userInfo = {
          id: res.data.data.id,
          first_name: res.data.data.first_name,
          last_name: res.data.data.last_name,
          avatar: res.data.data.avatar
        }
        commit('loginSuccess', userInfo)
      })
      .catch(err => {
        console.log(err);
        alert('이메일과 비밀번호를 확인 하세요.')
      })      
    }
  },
  modules: {}
});
