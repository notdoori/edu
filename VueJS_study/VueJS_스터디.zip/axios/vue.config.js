module.exports = {
  transpileDependencies: ["vuetify"]
  
};
