## 프로젝트 구성 시 view 폴더는 화면 레이아웃, components 폴더는 화면의 기능 수행 형태로 구성 하는 것이 좋음.

# vuex-project

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```
