import Vue from 'vue'
import './plugins/vuetify'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false

export const EventBus = new Vue()

new Vue({
  router, // 다른 컴포넌트 등에서 사용 시 $router, $route 와 같이 $ 붙여서 접근.
  store,  // 다른 컴포넌트 등에서 사용 시 $store 와 같이 $ 붙여서 접근.
  render: h => h(App)
}).$mount('#app')
