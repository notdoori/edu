import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: { // Vue 인스턴스의 data 역할
    allUsers:[
      {userId: 'hoza123', password: '123', name: 'IBS', address: 'Seoul', src:'https://goo.gl/oqLfJR'},
      {userId: 'max123', password: '456', name: 'IBS1', address: 'Berlin', src:'https://goo.gl/Ksk9B9'},
      {userId: 'lego123', password: '789', name: 'IBS2', address: 'Busan', src:'https://goo.gl/x7SpCD'}
    ]

  },
  getters: { // computed 와 같은 역할, state 의 data 리턴
    allUsersCount: function(state) { // function 의 인자는 사용할 store 의 속성 명 (state, getters, mutations 등)
      return state.allUsers.length;
    },
    // arrow function
    // allUsersCount: state => {
    //  return state.allUsers.length;
    //}
    countOfSeoul: state => {
      let count = 0;
      state.allUsers.forEach(user => { // user 는 allUsers 의 아이템을 가리킴.
        if (user.address === 'Seoul') count++;
      })
      return count;
    },
    percentOfSeoul: (state, getters)  => {
      return Math.round(getters.countOfSeoul / getters.allUsersCount * 100);
    }
  },
  mutations: { // state 의 data 변경, 동기식 처리
    addUsers: (state, payload) => { // 인자는 변경 대상 data, 변경 할 정보
      state.allUsers.push(payload);
    }
  },
  actions: { // mutation 을 동작 시키는 비즈니스 로직 등 기술.
    // addUsers: context => { // function(context) 와 동일
    //   context.commit('addUsers')
    // }
    addUsers: ({commit}, payload) => { // {commit} 은 context.commit.
      commit('addUsers', payload); // addUsers mutation 수행
    }
  }
})
