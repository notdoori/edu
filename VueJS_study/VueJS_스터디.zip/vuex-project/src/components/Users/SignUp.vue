<template>
  <div>
    <h1>사용자 정보</h1>
    <v-text-field
      label="사용자 아이디"
      v-model="userId"
    ></v-text-field>
    <v-text-field
      label="비밀 번호"
      type="password"
      v-model="password"
    ></v-text-field>
    <v-text-field
      label="사용자 이름"
      v-model="name"
    ></v-text-field>
    <v-select :items="lang"
      label="사용 언어"
      v-model="name"
      dense
    ></v-select>
    <v-select :items="items"
          label="부서"
          dense>      
    </v-select>
    <v-select :items="items1"
          label="사용자 그룹"
          dense>      
    </v-select>
    <!-- <v-select :items="items"
          label="권한 그룹"
          dense>
      
    </v-select> -->
    <!-- <v-text-field
      label="이름"
      v-model="name"
    ></v-text-field>
    <v-text-field
      label="주소"
      v-model="address"
    ></v-text-field>
    <v-text-field
      label="이미지"
      v-model="src"
    ></v-text-field> -->
    <v-btn @click="signUp">추가</v-btn>
    <v-btn @click="signUp">수정</v-btn>
    <v-btn @click="signUp">삭제</v-btn>
  </div>
</template>

<script>
import { EventBus } from '@/main.js'
// mapMutaions 이용
//import { mapMutations} from 'vuex'
// mapActions 이용
import { mapActions } from 'vuex'

  export default {
    data() {
      return {
        userId: null,
        password: null,
        name: null,
        address: null,
        src: null,
        lang: ['ko', 'en'],
        items: ['SI', 'SD', 'IT'],
        items1: ['OPERATOR', 'ADMIN', 'INFRA'],
      }
    },
    methods: { // store.js 에서 mutations 과 actions 객체는 다른 객체이므로 메소드 이름 동일하게 사용가능.
               // 현재 컴포넌트에서는 동일한 이름의 메소드 이므로 가능하면 다른 이름으로.
      // mapActions 이용
      ...mapActions(['addUsers']),
      // mapMutations 이용
      //...mapMutations(['addUsers']), // 현재 컴포넌트의 method 처럼 사용 가능.
      signUp() {
        let userObj = {
          userId: this.userId,
          password: this.password,
          name: this.name,
          address: this.address,
          src: this.src
        }
        //EventBus.$emit('signUp', userObj)
        // mapMutations 이용 
        //this.addUsers(userObj)
        // addUsers 라는 mutation 에 인자로 userObj 를 주고 실행 시킴.
        //this.$store.commit('addUsers', userObj);
        // store.js 의 actions 속성 사용
        //this.$store.dispatch('addUsers', userObj);
        //mapActions 이용
        this.addUsers(userObj)
        this.clearForm()
      },
      clearForm() {
        this.userId = null,
        this.password = null,
        this.name = null,
        this.address = null,
        this.src = null
      }
    }
  }
</script>