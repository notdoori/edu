<template>
  <div>
    <!-- <h1>All Users: {{ $store.getters.allUsersCount }}</h1> -->
    <!-- <h3>Seoul Users: {{ $store.getters.countOfSeoul }} ({{ $store.getters.percentOfSeoul }}%) </h3> -->
    <!-- mapGetters 사용  -->
    <!-- <h1>All Users: ({{ allUsersCount }})</h1>    
    <h3>Seoul Users: {{ countOfSeoul }} ({{ percentOfSeoul }}%) </h3> -->
    <!-- 현재 컴포넌트에서 지정한 이름으로 사용 -->
    <!-- <h1>All Users: ({{ count }})</h1>     -->
    <!-- <h3>Seoul Users: {{ seouls }} ({{ percent }}%) </h3> -->
    <!-- <v-list two-line> -->
    <h1>모든 사용자</h1>  
    <v-list>
      <v-list-tile
        v-for="(user, index) in allUsers/*mapState 이용*//*$store.state.allUsers*/"
        :key="index"
        avatar
      >
        <!-- <v-list-tile-avatar color="grey lighten-3">
          <img :src="user.src">
        </v-list-tile-avatar> -->

        <v-list-tile-content>
          <v-list-tile-title v-html="user.name"></v-list-tile-title>
          <!-- <v-list-tile-sub-title>id:#{{index}} / {{user.address}} 거주</v-list-tile-sub-title> -->
        </v-list-tile-content>
      </v-list-tile>
    </v-list>

  </div>
</template>

<script>
import { EventBus } from '@/main.js'
//mapGetters 사용
//import { mapGetters } from 'vuex';
//mapState, mapGetters 사용
import {mapGetters, mapState} from 'vuex'

  export default {
    data() {
      return {
        
      }
    },
    computed: {
      // 아래와 같이 선언해야 현재 컴포넌트에서 사용 할 수 있음.
      // [] 의 내용은 store.js 의 getters 속성에서 현재 컴포에서 사용하고자 하는 함수 명 모두 기술해야 함.
      //...mapGetters(['allUsersCount', 'countOfSeoul', 'percentOfSeoul'])
      ...mapGetters({
        count: 'allUsersCount', // $store.getters.allUserCount 를 현재 컴포넌트에서는 count 로 사용하겠다는 표시.
        seouls: 'countOfSeoul',
        percent: 'percentOfSeoul'
      }),
      ...mapState(['allUsers'])
    },
    mounted() {
      EventBus.$on('signUp', users => {
        //this.allUsers.push(users)
        this.$store.state.allUsers.push(users);
      })
    }
  }
</script>
