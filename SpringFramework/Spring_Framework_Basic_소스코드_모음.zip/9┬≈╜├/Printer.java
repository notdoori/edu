package myspring.di.annot;

public interface Printer {
	public void print(String message);
}
