console.log('Hello Node.js');
