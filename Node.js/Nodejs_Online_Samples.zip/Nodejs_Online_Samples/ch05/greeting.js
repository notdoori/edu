module.exports.hello = function() {
	console.log('Hello World');
}