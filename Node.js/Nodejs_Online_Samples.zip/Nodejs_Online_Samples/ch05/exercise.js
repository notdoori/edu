function Exercise() {
	
}

Exercise.prototype.run = function() {
	console.log('run!');
}
module.exports = Exercise; 