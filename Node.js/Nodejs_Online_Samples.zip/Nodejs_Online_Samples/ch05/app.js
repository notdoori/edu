var greeting = require('./greeting');
greeting.hello();


var Exercise = require('./exercise');
var exercise = new Exercise();
exercise.run();