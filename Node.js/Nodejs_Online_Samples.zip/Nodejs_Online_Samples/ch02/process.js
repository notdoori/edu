console.log(process.env);
console.log(process.arch);
console.log(process.platform);