function sayHello() {
	console.log('Hello World');
}

// 반복
setTimeout(function() {
	sayHello();
}, 2*1000);