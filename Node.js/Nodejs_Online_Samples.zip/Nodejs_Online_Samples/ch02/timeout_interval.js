// 반복
function sayGoodbye(who) {
   console.log('Good bye', who);   
}
setInterval(sayGoodbye, 1 * 1000, 'Friend');
