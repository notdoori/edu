var intVal = 3;
var obj = {
	name : 'NodeJS',
	how : 'Interesting'
};

console.log('hello world');
console.log('intVal : ' + intVal);
console.log('obj : ' + obj);
console.log('obj : ', obj);