// 0, 1은 node, processAdd.js
var i = process.argv[2];
var j = process.argv[3];
var sum = parseInt(i) + parseInt(j);
console.log(sum); // 8
